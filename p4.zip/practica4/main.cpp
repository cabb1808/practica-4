#include <iostream>
#include "red.h"

using namespace std;

int main()
{
    red a;
    return 0;
}
